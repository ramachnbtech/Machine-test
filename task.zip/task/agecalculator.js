function calculateAge(birthYear, currentYear) {
var age = currentYear - birthYear;
window.alert("You are either " + age + " or " + (age - 1));
}

