function calcCircumfrence(radius) {
var circumference = Math.PI * 2 * radius;
window.alert("The circumference is " + circumference);

var area = Math.PI * radius*radius;
window.alert("The area is " + area);
}
