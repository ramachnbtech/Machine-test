function ToFahrenheit(celsius) {
  var celsiusInF = (celsius*9)/5 + 32;
  window.alert(celsius + "�C is " + celsiusInF + "�F");
}

function fahrenheitToCelsius(fahrenheit) {
  var fahrenheitInC = ((fahrenheit - 32)*5)/9;
  window.alert(fahrenheit + "�F is " + fahrenheitInC + "�C");
}